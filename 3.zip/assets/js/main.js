/* ----- TYPING EFFECT ----- */
var typingEffect = new Typed(".typedText",{
    strings : ["Developer","Youtuber","Designer"],
    loop : true,
    typeSpeed : 80, 
    backSpeed : 50,
    backDelay : 2000
 })
